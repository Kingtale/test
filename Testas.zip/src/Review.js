import React, { useState } from "react";
import people from "/Review";

const Review = () => {
  return <h1>text</h1>;
};

export default Review;
